# play-java-forms-example

This example shows form processing and form helper handling in Play.

## How to run

Start the Play app:

```bash
sbt run
```

And open <http://localhost:9000/>

## Documentation

Please see <https://playframework.com/documentation/latest/JavaForms>.
