package actors;

public class SimillarProtocol {

    public static class SayHello2 {
        public final String name ;


        public SayHello2(String name) {
            this.name = name;
        }

    }
}
