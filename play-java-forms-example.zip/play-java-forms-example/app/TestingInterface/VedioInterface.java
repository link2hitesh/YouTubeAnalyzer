package TestingInterface;

import java.util.List;

public interface VedioInterface {

    public List<String> Find_Fields(String Query);

}
